<?php defined('_JEXEC') or die('Restricted access'); ?>
<div class="search-error">
	<div class="error-message">
		<?php echo $this->escape($this->error); ?>
	</div>
</div>