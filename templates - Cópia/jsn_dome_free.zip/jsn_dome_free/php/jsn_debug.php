<?php
/* jsn_debug.php @copyright (C) 2006-2008 JoomlaShine.com */

/*** REMOVAL OR MODIFICATION CODE BELLOW IS VIOLATION OF JOOMLASHINE.COM TERMS & CONDITIONS AND DEPRIVES OF ANY KIND OF SUPPORTS ***/
defined( '_JEXEC' ) or die( 'Restricted index access' );

if(strpos($copyright_text, 'http://www.joomlashine.com') == false) {
	echo '<div class="hd"><a href="http://www.joomlashine.com" title="Free Joomla Templates by JoomlaShine.com">Free Joomla Templates by JoomlaShine.com</a></div>';
}
?>