var chronoJQ = jQuery.noConflict();
